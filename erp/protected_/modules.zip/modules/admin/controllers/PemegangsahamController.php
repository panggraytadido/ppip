<?php 

class PemegangsahamController extends Controller
{
	public $layout='//layouts/column2';
	public $pageTitle = 'Admin - Pemegang Saham';
	
	
	public function actionIndex()
	{
		$model=new Pemegangsaham('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Pemegangsaham']))
			$model->attributes=$_GET['Pemegangsaham'];

		$this->render('index',array(
			'model'=>$model,
		));
	}
	
	public function actionCreate()
	{
		$model=new Jumlahsaham;		
		$this->performAjaxValidation($model);
		if(isset($_POST['Jumlahsaham']))
		{					
				$valid = $model->validate();
				if($valid)
				{ 
						$transaction = Yii::app()->db->beginTransaction();
						try{
								$model->attributes=$_POST['Jumlahsaham'];
								$anggota = Anggota::model()->findByPk($_POST['Jumlahsaham']['nama']);							
								$model->sahamid=Saham::model()->findByPk(1)->id;
								$model->anggotaid=$anggota->id;						
								$model->createddate=date("Y-m-d H:", time());;
								$model->userid=Yii::app()->user->id;
								if($model->save()) 
								{
									$transaction ->commit();	
									
									echo CJSON::encode(array
									(
										'result'=>'OK',
									));    	
									 Yii::app ()->user->setFlash ( 'success', "Data Pemegang Saham Berhasil diTambahkan" );
									Yii::app()->end();
								}
						}
						catch (Exception $error) 
						{
							$transaction ->rollback();
							throw $error;
						} 
						
				}
				else
				{
						$error = CActiveForm::validate($model);
						if($error!='[]')
								echo $error;
						Yii::app()->end();
				}	


				Yii::app()->end();
		}
		
		$this->layout='';
		$this->renderPartial('_form',array(
				'model'=>$model,			
		), false, true );

		Yii::app()->end();
		
	}
	
	public function actionUpdate($id)
	{
		$model = Anggota::model()->findByPk($id);
		$totalSaham = Pemegangsaham::model()->Gettotalsaham($id);
		$this->performAjaxValidationUpdate($model);
		
		if(isset($_POST['Pemegangsaham']))
        {
			
		}
		
		$this->layout='';
		$this->renderPartial('_updateform',array(
				'model'=>$model,
				'totalSaham'=>number_format($jumlahSaham),
				'jumlahSaham'=>	Pemegangsaham::model()->getJumlahSaham($_POST['anggotaid'])
		), false, true );

		Yii::app()->end();		
	}
	
	
	public function actionGetjumlahsaham()
	{
		if (Yii::app ()->request->isAjaxRequest) {
				
			$pemegangSaham = Pemegangsaham::model()->getJumlahSaham($_POST['anggotaid']);	
			echo CJSON::encode(array
			(
				'jumlah'=>$pemegangSaham
			));    	
		}	
	}
	
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
	
	protected function performAjaxValidationUpdate($model)
        {
            if(isset($_POST['ajax']) && $_POST['ajax']==='form')
            {
                echo CActiveForm::validate(array($model1));
                Yii::app()->end();
            }
        }
        
	
	
	
	
}