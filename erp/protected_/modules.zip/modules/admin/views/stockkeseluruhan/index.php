<?php
$this->pageTitle = "Stock Keseluruhan - Admin";

$this->breadcrumbs=array(
	'Admin',
        'Stock Keseluruhan',
);

?>

<style>
.stock-kosong {
    background:#FFF6BF;
    color:#514721;
}

</style>    

<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">                     
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <div class="pull-left">
                        <b>Gudang - Stock Keseluruhan</b>
                    </div>
                    <div class="pull-right">
                        <a href="" class="btn btn-info btn-xs"><i class="fa fa-refresh"></i> Refresh</a>
                    </div>
                </div>
                
                <div class="ibox-content">

                    <?php if(Yii::app()->user->hasFlash('success')):?>
                            <div class="alert alert-success fade in">
                                <button type="button" class="close close-sm" data-dismiss="alert">
                                    <i class="fa fa-times"></i>
                                </button>
                                <?php echo Yii::app()->user->getFlash('success'); ?>
                            </div>    
                    <?php endif; ?>


<?php $this->widget('booster.widgets.TbGridView', array(
	'id'=>'stockupdate-grid',
        'type' => 'striped bordered hover',
        'responsiveTable'=>true,        
	'dataProvider'=>$model->search(),
        //'rowCssClassExpression' => ('$data->jumlah==0')?'stock-kosong':'',
	'filter'=>$model,
	'columns'=>array(
		array(
                    'header'=>'No',
                    'class'=>'IndexColumn',
                ),		
                array(
            				'class'=>'booster.widgets.TbRelationalColumn',
            				//'name' => 'firstLetter',
            				'header'=>'Detail Barang',
            				'url' =>$this->createUrl("stockkeseluruhan/detail"),
            				'value'=> '"<span class=\"fa fa-plus\"></span>"',
            				'htmlOptions'=>array('width'=>'100px'),            				
            				'type'=>'html',
            				'afterAjaxUpdate' => 'js:function(tr,rowid,data){
            		
            }'
            		),
                array('name'=>'divisi','value'=>'$data->divisi','header'=>'Divisi','filter'=>  CHtml::dropDownList('Stockkeseluruhan[divisi]','nama',
                                    CHtml::listData(Divisi::model()->findAll(),'id','nama'),
                                    array(
                                        'id'=>'User_divisi',
                                        'class'=>"form-control",
                                        'prompt'=>'Pilih Divisi',
                                    )),),        
		array('name'=>'kode','value'=>'$data->kode','header'=>'Kode Barang'),
		array('name'=>'nama','value'=>'$data->nama','header'=>'Nama Barang'),
                array('name'=>'total','value'=>function($data,$row){
                    return Stockkeseluruhan::model()->getTotalStock($data->id);
                },'header'=>'Total','filter'=>false),
                
	),
)); ?>

                </div>
            </div>	              
        </div>
    </div>
</div>