<?php
$this->pageTitle = "Set Jenis Pembayaran - Kasir";

$this->breadcrumbs=array(
	'Kasir','Set Jenis Pembayaran'
);
?>
                     
                    <form class="form-horizontal">
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Tanggal</label>
                            <div class="col-lg-3">
                            <input class="form-control" disabled="disabled" value="<?php echo $tanggal; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Pelanggan</label>
                            <div class="col-lg-6">
                                <input class="form-control" disabled="disabled" value="<?php echo $pelanggan ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Jenis Pembayaran</label>
                            <div class="col-lg-6">
                                <h3 style="color:green;">Set Jenis Pembayaran Menjadi Kredit (Data Setoran)</h3>
                            </div>
                        </div>                       
                    </form>    
                    <br>
                   
                    <input type="hidden" name="pelangganid" value="<?php //echo $pelangganid ?>" >
                    <input type="hidden" name="tanggal" value="<?php //echo $tanggal ?>" >
                    
                    <br>
                    <div class="pull-left">
                         <?php 
                            echo CHtml::ajaxSubmitButton('Simpan',CHtml::normalizeUrl(array('inbox/setjenispembayaran','pelangganid'=>$pelangganid,'tanggal'=>$tanggal)),
                                array(
                                    'dataType'=>'json',
                                    'type'=>'POST',                      
                                    'success'=>'js:function(data) 
                                     {    

                                       if(data.result==="OK")
                                       {             
                                          location.href="'.Yii::app()->baseurl.'/kasir/datasetoran";
                                       }
                                       else
                                       {                        
                                           $.each(data, function(key, val) 
                                           {
                                               $("#gudangpenjualanbarang-form #"+key+"_em_").text(val);                                                    
                                               $("#gudangpenjualanbarang-form #"+key+"_em_").show();
                                           });
                                       }       
                                   }'               
                                    ,                                    
                                    'beforeSend'=>'function()
                                     {                        
                                          $("#AjaxLoader").show();

                                     }'
                                ),array('id'=>'btnSave','class'=>'btn btn-primary'));      
                        ?> 
                                                                  
                        
                    </div>  
                    <br>