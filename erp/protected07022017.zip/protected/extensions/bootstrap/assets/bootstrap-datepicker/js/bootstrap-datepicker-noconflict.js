var bootstrapDatePicker;

(function ($) {
	bootstrapDatePicker = $.fn.datepicker;
})(jQuery);