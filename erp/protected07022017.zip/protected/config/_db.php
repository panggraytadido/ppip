<?php

return array (
    'class' => 'CDbConnection',
    'connectionString' => 'pgsql:host=127.0.0.1;port=5432;dbname=ppip',
    //'connectionString' => 'pgsql:host=localhost;port=5435;dbname=mkmppg1',
    'username' => 'postgres',
    'password' => 'dido',
    'charset' => 'utf8',
    'enableProfiling' => true,
    'enableParamLogging' => true
);
